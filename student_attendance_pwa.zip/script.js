const MONTHS=["January","February","March","April","May","June","July","August","September","October","November","December"];
const START_YEAR=2020,END_YEAR=2040;
const KEY={students:"SA_students_v1",attendance:"SA_attendance_v1",id:"SA_teacher_id_v1",pass:"SA_teacher_password_v1",login:"SA_logged_in",name:"SA_teacher_name"};
let students=JSON.parse(localStorage.getItem(KEY.students)||"[]");
let attendance=JSON.parse(localStorage.getItem(KEY.attendance)||"{}");
let teacherId=localStorage.getItem(KEY.id)||"teacher";
let teacherPassword=localStorage.getItem(KEY.pass)||"1234";

const $=id=>document.getElementById(id);
const today=()=>new Date().toISOString().slice(0,10);
function save(){localStorage.setItem(KEY.students,JSON.stringify(students));localStorage.setItem(KEY.attendance,JSON.stringify(attendance));}
function years(select){select.innerHTML="";for(let y=START_YEAR;y<=END_YEAR;y++)select.add(new Option(y,y));}
function months(select){select.innerHTML="";MONTHS.forEach((m,i)=>select.add(new Option(m,i)));}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),2200);}
function showLogin(){$("appPage").classList.add("hidden");$("loginPage").classList.remove("hidden");$("teacherId").focus();}
function showApp(){$("loginPage").classList.add("hidden");$("appPage").classList.remove("hidden");$("teacherDisplay").textContent="Teacher: "+(sessionStorage.getItem(KEY.name)||teacherId);openPage("dashboard");}
function checkLogin(){sessionStorage.getItem(KEY.login)==="1"?showApp():showLogin();}

function openPage(name){
  document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
  $(name+"Page").classList.remove("hidden");
  document.querySelectorAll("[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
  $("sidebar").classList.remove("open");
  if(name==="dashboard")refreshDashboard();
  if(name==="students")renderStudents();
  if(name==="attendance")renderAttendance();
  if(name==="history")renderHistory();
  if(name==="reports")renderReports();
}

function refreshDashboard(){
  $("totalStudents").textContent=students.length;
  const a=attendance[today()]||{}, present=students.filter(s=>a[s.id]==="present").length, absent=students.filter(s=>a[s.id]==="absent").length;
  $("presentToday").textContent=present;$("absentToday").textContent=absent;
  $("todayRate").textContent=(present+absent?Math.round(present/(present+absent)*100):0)+"%";
  const y=Number($("dashboardYear").value)||new Date().getFullYear();
  $("dashboardSelectedYear").textContent=y+" Monthly Overview";
  const grid=$("monthGrid");grid.innerHTML="";
  MONTHS.forEach((m,i)=>{const dates=Object.keys(attendance).filter(d=>d.startsWith(y+"-"+String(i+1).padStart(2,"0")+"-"));let p=0,total=0;
    dates.forEach(d=>students.forEach(s=>{if(attendance[d][s.id]==="present"){p++;total++}else if(attendance[d][s.id]==="absent")total++}));
    const rate=total?Math.round(p/total*100):0;grid.insertAdjacentHTML("beforeend",`<div class="month-card"><b>${m}</b><span>${rate}% • ${p}/${total} marked present</span></div>`);
  });
}
function renderStudents(){
  const q=$("studentSearch").value.trim().toLowerCase();const rows=students.filter(s=>(s.name+" "+s.roll).toLowerCase().includes(q));
  $("studentTable").innerHTML=rows.map(s=>`<tr><td>${esc(s.roll)}</td><td>${esc(s.name)}</td><td><div class="actions"><button class="btn" onclick="editStudent('${s.id}')">Edit</button><button class="btn del" onclick="deleteStudent('${s.id}')">Delete</button></div></td></tr>`).join("");
  $("noStudents").classList.toggle("hidden",rows.length>0);
}
function openStudent(id=""){const s=students.find(x=>x.id===id);$("editStudentId").value=id;$("studentRoll").value=s?.roll||"";$("studentName").value=s?.name||"";$("modalTitle").textContent=s?"Edit Student":"Add Student";$("studentModal").classList.remove("hidden");$("studentRoll").focus();}
function closeStudent(){$("studentModal").classList.add("hidden");}
window.editStudent=openStudent;
window.deleteStudent=function(id){if(!confirm("Delete this student?"))return;students=students.filter(s=>s.id!==id);Object.keys(attendance).forEach(d=>delete attendance[d][id]);save();renderStudents();toast("Student deleted");};
function renderAttendance(){
  const date=$("attendanceDate").value||today();const a=attendance[date]||{};$("attendanceDate").value=date;
  $("noAttendanceStudents").classList.toggle("hidden",students.length>0);$("attendanceList").innerHTML=students.map(s=>{const st=a[s.id]||"";return `<div class="attendance-row"><div class="student-info"><b>${esc(s.name)}</b><span>Roll: ${esc(s.roll)}</span></div><div class="attendance-buttons"><button class="att-btn present ${st==="present"?"active":""}" onclick="markAttendance('${s.id}','present')">Present</button><button class="att-btn absent ${st==="absent"?"active":""}" onclick="markAttendance('${s.id}','absent')">Absent</button></div></div>`}).join("");updateSummary();
}
window.markAttendance=function(id,status){const d=$("attendanceDate").value||today();attendance[d] ||= {};attendance[d][id]=status;save();renderAttendance();};
function updateSummary(){const a=attendance[$("attendanceDate").value]||{};const p=students.filter(s=>a[s.id]==="present").length,ab=students.filter(s=>a[s.id]==="absent").length;$("attendanceTotal").textContent=students.length;$("attendancePresent").textContent=p;$("attendanceAbsent").textContent=ab;}
function renderHistory(){const d=$("historyDate").value||today();$("historyDate").value=d;const a=attendance[d]||{};$("historyResult").innerHTML=`<h3>${new Date(d+"T00:00:00").toLocaleDateString()}</h3>`+(students.length?`<table><thead><tr><th>Roll</th><th>Student</th><th>Status</th></tr></thead><tbody>${students.map(s=>`<tr><td>${esc(s.roll)}</td><td>${esc(s.name)}</td><td>${a[s.id]==="present"?"Present":a[s.id]==="absent"?"Absent":"Not Marked"}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">No students.</div>`);}
function renderReports(){const y=Number($("reportYear").value)||new Date().getFullYear();$("reportTable").innerHTML=students.map(s=>`<tr><td>${esc(s.roll)}</td><td>${esc(s.name)}</td>${MONTHS.map((_,i)=>{let p=0,t=0;Object.keys(attendance).forEach(d=>{if(d.startsWith(y+"-"+String(i+1).padStart(2,"0")+"-")){const st=attendance[d][s.id];if(st==="present"){p++;t++}else if(st==="absent")t++}});return `<td>${t?Math.round(p/t*100):0}%</td>`}).join("")}</tr>`).join("");}

$("loginForm").addEventListener("submit",e=>{e.preventDefault();if($("teacherId").value.trim()===teacherId&&$("teacherPassword").value===teacherPassword){sessionStorage.setItem(KEY.login,"1");sessionStorage.setItem(KEY.name,teacherId);$("loginError").textContent="";showApp()}else $("loginError").textContent="Incorrect Teacher ID or password."});
$("logoutButton").onclick=()=>{sessionStorage.removeItem(KEY.login);sessionStorage.removeItem(KEY.name);showLogin();};
document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>openPage(b.dataset.page));
$("menuButton").onclick=()=>$("sidebar").classList.toggle("open");
$("addStudentButton").onclick=()=>openStudent();
$("closeModal").onclick=closeStudent;$("cancelModal").onclick=closeStudent;
$("studentForm").onsubmit=e=>{e.preventDefault();const id=$("editStudentId").value,roll=$("studentRoll").value.trim(),name=$("studentName").value.trim();if(!roll||!name)return;if(students.some(s=>s.roll.toLowerCase()===roll.toLowerCase()&&s.id!==id)){toast("Roll number already exists");return}if(id){Object.assign(students.find(s=>s.id===id),{roll,name})}else students.push({id:Date.now().toString(36)+Math.random().toString(36).slice(2),roll,name});save();closeStudent();renderStudents();refreshDashboard();toast("Student saved")};
$("studentSearch").oninput=renderStudents;
$("attendanceDate").onchange=renderAttendance;
$("allPresentButton").onclick=()=>{const d=$("attendanceDate").value||today();attendance[d] ||= {};students.forEach(s=>attendance[d][s.id]="present");save();renderAttendance();};
$("allAbsentButton").onclick=()=>{const d=$("attendanceDate").value||today();attendance[d] ||= {};students.forEach(s=>attendance[d][s.id]="absent");save();renderAttendance();};
$("saveAttendanceButton").onclick=()=>{save();toast("Attendance saved")};
$("historyDate").onchange=renderHistory;
$("dashboardYear").onchange=refreshDashboard;$("dashboardMonth").onchange=refreshDashboard;
$("reportYear").onchange=renderReports;
$("settingsForm").onsubmit=e=>{e.preventDefault();const id=$("newTeacherId").value.trim(),p=$("newTeacherPassword").value,c=$("confirmTeacherPassword").value;if(!id||!p)return;if(p!==c){toast("Passwords do not match");return}teacherId=id;teacherPassword=p;localStorage.setItem(KEY.id,id);localStorage.setItem(KEY.pass,p);sessionStorage.setItem(KEY.name,id);$("teacherDisplay").textContent="Teacher: "+id;toast("Credentials updated")};
$("exportButton").onclick=()=>{const y=Number($("reportYear").value);let csv=["Roll,Student,"+MONTHS.join(",")];students.forEach(s=>{let vals=MONTHS.map((_,i)=>{let p=0,t=0;Object.keys(attendance).forEach(d=>{if(d.startsWith(y+"-"+String(i+1).padStart(2,"0")+"-")){const st=attendance[d][s.id];if(st==="present"){p++;t++}else if(st==="absent")t++}});return t?Math.round(p/t*100)+"%":"0%"});csv.push([s.roll,s.name,...vals].map(v=>`"${String(v).replaceAll('"','""')}"`).join(","))});const blob=new Blob([csv.join("\\n")],{type:"text/csv"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`attendance-${y}.csv`;a.click();URL.revokeObjectURL(a.href)};
function init(){months($("dashboardMonth"));years($("dashboardYear"));years($("reportYear"));const now=new Date();$("dashboardMonth").value=now.getMonth();$("dashboardYear").value=now.getFullYear();$("reportYear").value=now.getFullYear();$("attendanceDate").value=today();$("historyDate").value=today();checkLogin()}
init();