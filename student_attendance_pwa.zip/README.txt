STUDENT ATTENDANCE PWA

This is an installable Progressive Web App (PWA) version of the Student Attendance website.

Default login:
Teacher ID: teacher
Password: 1234

IMPORTANT:
A PWA cannot be installed from a normal file:// URL on most phones. It must be opened from HTTPS (or localhost during development).

EASIEST PHONE INSTALL:
1. Put this entire folder on an HTTPS web host.
2. Open the HTTPS address in Chrome on Android.
3. Tap the browser menu (⋮).
4. Choose "Install app" or "Add to Home screen".
5. Open the new Student Attendance icon. It will run in standalone app mode.
6. After the first successful load, the service worker caches the app so the app shell can work offline.

The attendance data is stored in the browser's local storage on the device. Clearing the site's browser data can erase saved records.
